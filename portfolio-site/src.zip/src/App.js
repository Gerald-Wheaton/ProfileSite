import React, { Component } from 'react'
import LandingPage from "./Components/LandingPage"
import AboutMe from "./Components/AboutMe"
import Resume from "./Components/Resume"
import ContactMe from "./Components/ContactMe"
import MyGithub from "./Components/MyGithub"
import Nav from './Components/Nav'
import SideBar from "./Components/SideBar"

import {
    BrowserRouter as Router,
    Route,
    Switch,
    Link
  } from "react-router-dom"



class App extends Component {
  render() {
    return (
        <Router>
            <div>
                <SideBar />
                    <Switch>
                        <Route path="/" exact component={LandingPage} />
                        <Route path="/about" component={AboutMe} />
                        <Route path="/resume" component={Resume} />
                        <Route path="/contact" component={ContactMe} />
                        <Route path="/github" component={MyGithub} />
                    </Switch>
            </div>
        </Router>
    )
  }
}

export default App;
