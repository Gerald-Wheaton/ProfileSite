const CardInfo = [
    {
        id: 1,
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris sagittis pellentesque lacus eleifend lacinia...",
        image: "https://www.xyzapk.com/wp-content/uploads/2017/11/com.woodencloset.paintsplash.jpg.png",
        button: "Get Started"
    }
]

export default CardInfo