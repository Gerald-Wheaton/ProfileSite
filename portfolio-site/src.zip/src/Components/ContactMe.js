import React from "react"

function ContactMe() {
    return (
        <div>
            <h1>Contact Me Page</h1>
        </div>
    )
}

export default ContactMe