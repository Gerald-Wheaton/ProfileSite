import React from "react"
import ThingToKnow from "./ThingToKnow"

function Resume() {
    return (
        <div>
            <h1>Resume Page</h1>
            <ThingToKnow />
        </div>
    )
}

export default Resume