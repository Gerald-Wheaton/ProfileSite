import React from "react"

function MyGithub() {
    return (
        <div>
            <h1>Github Page</h1>
            
        </div>
    )
}

export default MyGithub