import React from "react"
import "./styles.css"

function LandingPage() {
    return (
        <div>
            <h1>Landing Page</h1>
        </div>
    )
}

export default LandingPage